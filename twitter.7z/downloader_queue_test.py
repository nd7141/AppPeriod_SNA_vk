import pika, sys, time, pymongo

r_connection = pika.BlockingConnection(pika.ConnectionParameters(
               'localhost'))
channel = r_connection.channel()
Q = "download_friends"
channel.queue_declare(queue=Q, 
                arguments={'x-message-ttl':600000})   
m_connection = pymongo.Connection('127.0.0.1', 27017)
m_connection.admin.authenticate('admin', 'soc')
db = m_connection.tweets




for item in db.good.find().sort("time",-1):
    n = channel.queue_declare(queue=Q, passive=True, arguments={'x-message-ttl':600000}).method.message_count
    message = item['user']['id']
    print message
    if db.friends.find_one({"_id": str(message)}) != None:
        print "user exists"
	continue
    if n > 2000:
        time.sleep(0.1* (n - 20))
    channel.basic_publish(exchange='',
                      routing_key=Q,
                      body=str(message))
