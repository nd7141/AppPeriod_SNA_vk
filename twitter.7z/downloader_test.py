from twython import Twython, TwythonError
from pymongo import Connection
import pika, time

connection = Connection("localhost")
connection.admin.authenticate('admin', 'soc')
db = connection['tweets']

consumer_key="vo0Wgb0a7a9ZifGktag"
consumer_secret="olX8s4Phv3aWpNDBfPevHdQVl4OjhAbalkYuw"

access_token="1551086023-jpGINWnLcVhTWNFiWFaFXUKGf8FDPzUOgkW"
access_token_secret="NU34LSDrtaluFhd1QsVENMyoV7XZJEE6ttCKmw"

t = Twython(app_key=consumer_key,
            app_secret=consumer_secret,
            oauth_token=access_token,
            oauth_token_secret=access_token_secret)

Q ='download_friends'

r_connection = pika.BlockingConnection(pika.ConnectionParameters(
               'localhost'))
channel = r_connection.channel()
channel.queue_declare(queue= Q, 
                arguments={'x-message-ttl':600000})   


while 1:
    method_frame, header_frame, id = channel.basic_get(Q)
    if db.friends.find_one({"_id": id}) != None:
	print db.friends.find_one({"_id": id})
        print "Panic, user already exists"
	continue
    try:
    	r = t.get_friends_list(user_id = id)
    except Exception as ex:
	print ex, id
    else:
    	print id
	r['_id'] = id
        r['time'] = time.time()
        db.friends.save(r)

    time.sleep(121)

        

#print dir(t)
#r = t.get_friends_list(screen_name = 'navalny')
#print type(r)
#for f in r['users']:
#    print f['name'], "###", f['description']

#for tweet in search_results['statuses']:
#    print 'Tweet from @%s Date: %s' % (tweet['user']['screen_name'].encode('utf-8'), tweet['created_at'])
#    print tweet['text'].encode('utf-8'), '\n'
